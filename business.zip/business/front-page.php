<?php 
    /*
        Template Name: Blog Page
    */
?>
<?php get_header();?>
    <!-- == Color schemes == -->
	  <div class="color-schemes">
	  	 <div class="color-handle">
             <i class="fa fa-cogs fa-spin" aria-hidden="true"></i>
	  	 </div>
	  	 <div class="color-plate">
	  		 <h5>Chose color</h5>
  		     <a href="css/colors/defaults-color.css" class="single-color defaults-color">Defaults</a>
             <a href="css/colors/red-color.css" class="single-color red-color">Red</a>
             <a href="css/colors/purple-color.css" class="single-color purple-color">Purple</a>
             <a href="css/colors/sky-color.css" class="single-color sky-color">sky</a>
             <a href="css/colors/green-color.css" class="single-color green-color">Green</a>
             <a href="css/colors/blue-color.css" class="single-color pink-color">Pink</a>
	  	  </div>
	  </div>
      <?php $blog_breadcom_img = get_option('business');?>
     <!-- == /Color schemes == -->
    <section class="page-title page-bg bg-opacity section-padding" style="background-image: url(<?php echo $blog_breadcom_img['blog_page_bread']['url'];?>);">
    	<div class="container">
    		<div class="row">
    			<div class="col-md-12">
    				<h2><?php the_title(); ?></h2>
    				<div class="breadcrumb">
    					<ul>
    						<li><a href="<?php the_permalink();?>"><?php get_breadcrumb(); ?></a></li>
    					</ul>
    				</div>
    			</div>
    		</div>
    	</div>
    </section>
   <!-- start blog-main-section -->
        <section class="blog-main-section section-padding">
            <div class="container">
               <div class="row">
                   <?php get_template_part('templates/template','blogpost');?>
                    <div class="col col-lg-3">
                      <div class="blog-sidebar">
                       
                                <?php dynamic_sidebar('serach_box');?>
                                <?php dynamic_sidebar('catagory_post_widget');?>
                        
                            
                            <div class="widget recent-posts-widget">
                              <!--   <h3>Recent posts</h3>
                                <div class="post">
                                    <h4><a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </a></h4>
                                    <span class="date">Aug 08, 2017</span>
                                </div> -->
                                <?php dynamic_sidebar('recent_post')?>
                            </div>
                            <div class="widget tags-widget">
                                <?php dynamic_sidebar('tag_cloud')?>
                            </div>
                            <div class="widget subscribe search-widget">
                               <h3>Subscribe</h3>
                               <p>Lorem ipsum dolor sit amet, conse ctetur adipisicing</p>
                                 <form class="form">
                                    <div>
                                        <input type="text" class="form-control" placeholder="Enter your email here...">
                                        <button type="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
                                    </div>
                                </form>
                            </div>
                            <div class="widget subscribe search-widget">
                               <h3>Follow us in social</h3>
                                 <div class="blog-social">
                                    <ul class="social-profile-blog">
                                      <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                      <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                      <li><a href="#"><i class="fa fa-google-plus"></i></a></li>                                 
                                    </ul>
                                </div> 
                            </div>
                      </div>
                    </div>
               </div>     
         </div> <!-- end container -->
    </section>
    <!-- end blog-main-section -->
    <?php get_footer(); ?>

