<?php 

/***

Business functions and definitions
***/

// them setup function



function business_function(){

	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
	add_image_size('slider',1280,560);
	add_image_size('about',557,374);
	add_image_size('ourteam', 264,264);
	add_image_size('ourteam_deta', 360,360);
	add_image_size('testimonial', 113,110);
	add_image_size('clie', 220,110);
	add_image_size('portfolio', 366,246);
	add_image_size('blogpost',410,264);
	
}

register_nav_menus(
	array(
		'header_menu' => 'Header Menu',
	)
);
register_nav_menus(
	array(
		'footer_menu' => 'Footer Menu',
	)
);

add_action('after_setup_theme', 'business_function');




add_action('wp_enqueue_scripts', 'business_script');

function business_script(){
	
	wp_enqueue_style('main_css', get_template_directory_uri().'/css/bootstrap.min.css');
	wp_enqueue_style('animate', get_template_directory_uri().'/css/animate.min.css');
	wp_enqueue_style('carousel', get_template_directory_uri().'/css/owl.carousel.css');
	wp_enqueue_style('slick', get_template_directory_uri().'/css/slick.css');
	wp_enqueue_style('slicknav', get_template_directory_uri().'/css/slicknav.min.css');
	wp_enqueue_style('slick_theme', get_template_directory_uri().'/css/slick-theme.css');
	wp_enqueue_style('font_awesome', get_template_directory_uri().'/css/font-awesome.min.css');
	wp_enqueue_style('icofont', get_template_directory_uri().'/css/icofont.css');
	wp_enqueue_style('lineprogressbar', get_template_directory_uri().'/css/jquery.lineProgressbar.min.css');
	wp_enqueue_style('owl_theme', get_template_directory_uri().'/css/owl.theme.default.css');
	wp_enqueue_style('magnific', get_template_directory_uri().'/css/magnific-popup.css');
	wp_enqueue_style('stylesheet', get_template_directory_uri().'/css/style.css');
	wp_enqueue_style('responsive_r', get_template_directory_uri().'/css/responsive.css');
	wp_enqueue_style('defaults-color', get_template_directory_uri().'/css/colors/defaults-color.css');
	
}







function load_css_js() {

	

    wp_enqueue_script('bootstrap_min_js', get_template_directory_uri() . '/js/bootstrap.min.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('jquery_parallax', get_template_directory_uri() . '/js/jquery.parallax-1.1.3.js', array( 'jquery' ), '', true);
    wp_enqueue_script('slick_min_j', get_template_directory_uri() . '/js/slick.min.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('slick_min_j', get_template_directory_uri() . '/js/slick.min.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('magnific_popup', get_template_directory_uri() . '/js/jquery.magnific-popup.min.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('wow_min_js', get_template_directory_uri() . '/js/wow.min.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('isotope', get_template_directory_uri() . '/js/isotope.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('owl_carousel_min', get_template_directory_uri() . '/js/owl.carousel.min.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('jquery_waypoints', get_template_directory_uri() . '/js/jquery.waypoints.min.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('lineProgressbar', get_template_directory_uri() . '/js/jquery.lineProgressbar.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('counterup_min', get_template_directory_uri() . '/js/jquery.counterup.min.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('slicknav_min', get_template_directory_uri() . '/js/jquery.slicknav.min.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('tweetie_js', get_template_directory_uri() . '/js/tweetie.js', array( 'jquery' ) , '', true);
    wp_enqueue_script('theme_jsss', get_template_directory_uri() . '/js/main.js', array( 'jquery' ) , '', true);
    
    
}

add_action('wp_enqueue_scripts', 'load_css_js');




require_once get_theme_file_path() .'/inc/codestar-framework/codestar-framework.php';

require_once('inc/theme_option.php');

 if( file_exists(dirname(__FILE__)) . '/inc/business_custom_post.php' ){
	require_once( dirname(__FILE__) . '/inc/business_custom_post.php' );
} 

if( file_exists(dirname(__FILE__)) . '/inc/business_cusom_metabox.php' ){
	require_once( dirname(__FILE__) . '/inc/business_cusom_metabox.php' );
}
if( file_exists(dirname(__FILE__)) . '/inc/business_widget.php' ){
	require_once( dirname(__FILE__) . '/inc/business_widget.php' );
}
if (file_exists(dirname(__FILE__)) . '/inc/breadcrumb.php' ) {
	require_once( dirname(__FILE__) . '/inc/breadcrumb.php');
}
if (file_exists(dirname(__FILE__)) . '/inc/business_custom_widget.php') {
	require_once(dirname(__FILE__) . '/inc/business_custom_widget.php');
}

/**
 * Generate breadcrumbs
 * @author CodexWorld
 * @authorURL www.codexworld.com
 */
function get_breadcrumb() {
    echo '<a href="'.home_url().'" rel="nofollow">Home</a>';
    if (is_category() || is_single()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
        the_category(' &bull; ');
            if (is_single()) {
                echo " &nbsp;&nbsp;&#187;&nbsp;&nbsp; ";
                the_title();
            }
    } elseif (is_page()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
        echo the_title();
    } elseif (is_search()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;Search Results for... ";
        echo '"<em>';
        echo the_search_query();
        echo '</em>"';
    }
}