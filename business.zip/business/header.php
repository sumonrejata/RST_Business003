<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	
	<meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Business: Business Multipurpose HTML template">
    <meta name="keywords" content="bootweb, multipurpose, portfolio, personal, developer, designer, onepage, clean, minimal, modern">
    <meta name="author" content="Tanmoy Dhar">
	
	  <!-- All CSS Files -->
    <link rel="shortcut icon" href="#" type="image/png">
    
    
  
   <?php wp_head(); ?>

</head>
<body>
     <!-- ==== Preloader start ==== -->
   <div id="loader-wrapper">
         <div id="loader"></div>
         <div class="loader-section section-left"></div>
         <div class="loader-section section-right"></div>
   </div>
   <!-- ==== Preloader end ==== -->
        <!-- Header start -->
    <header>
      <div class="hidden-xs hidden-sm nav-top primary-bg">
        <div class="container">
          <div class="row">
            <div class="col-sm-6">
              <div class="nav-top-access">
                <!-- Social links -->
                <?php $header_section = get_option('business'); ?>
                <ul>
                    <?php if($header_section['phone_n']) : ?>
                  <li><i class="fa fa-phone"></i> + <?php echo $header_section['phone_n'];?></li>
              <?php endif; ?>
              <?php if($header_section['header_email']) :?>
                  <li><i class="fa fa-envelope" aria-hidden="true"></i> <?php echo $header_section['header_email'];?></li>
              <?php endif; ?>
                </ul>
              </div>
            </div>
            <div class="col-sm-6 text-right">
              <div class="nav-top-social">
                <ul>
                    <?php if($header_section['facebook_icon']) : ?>
                    <li>
                        <a href="<?php echo $header_section['facebook_link'];?>"><i class="fa fa-<?php echo $header_section['facebook_icon'];?>"></i>
                    </a>
                    </li>
                <?php endif;?>
                <?php if($header_section['twitter_icon']) : ?>
                    <li><a href="<?php echo $header_section['twitter_link'];?>"><i class="fa fa-<?php echo $header_section['twitter_icon'];?>"></i></a></li>
                <?php endif;?>
                <?php if($header_section['linkedin_icon']) : ?>
                    <li><a href="<?php echo $header_section['linkedin_link'];?>"><i class="fa fa-<?php echo $header_section['linkedin_icon'];?>"></i></a></li>
                <?php endif;?>
                <?php if($header_section['pinterest_icon']) : ?>
                    <li><a href="<?php echo $header_section['pinterest_link'];?>"><i class="fa fa-<?php echo $header_section['pinterest_icon'];?>"></i></a></li>
                <?php endif;?>
                <?php if($header_section['instagram_icon']) : ?>
                    <li><a href="<?php echo $header_section['instagram_link'];?>"><i class="fa fa-<?php echo $header_section['instagram_icon'];?>"></i></a></li>
                <?php endif;?>
                <?php if($header_section['google_plus_icon']) : ?>
                    <li><a href="<?php echo $header_section['google_plus_link'];?>"><i class="fa fa-<?php echo $header_section['google_plus_icon'];?>"></i></a></li>
                <?php endif;?>
                <?php if($header_section['youtube_play_icon']) : ?>
                    <li><a href="<?php echo $header_section['youtube_play_link'];?>"><i class="fa fa-<?php echo $header_section['youtube_play_icon'];?>"></i></a></li>
                <?php endif;?>
                    
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
            <div class="menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <?php if($header_section['header_logo_1']) : ?>
                            <div class="logo">
                                <!--== change the logo name ==-->
                                <a href="<?php bloginfo('home'); ?>">
                                   <h3><span><?php echo $header_section['header_logo_1'];?></span><?php echo $header_section['header_logo_2'];?></h3>
                                </a>
                            </div>
                        <?php endif; ?>
                            <!-- Responsive Menu Start -->
                            <div class="responsive-menu"></div>
                            <!-- Responsive Menu End -->
                        </div>
                        <div class="col-md-9 col-sm-12">
                            <div class="mainmenu">
                            <?php
                               wp_nav_menu(array(
                                'theme_location' => 'header_menu',
                                'container' => ''
                            ));
                            ?>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </header>
    <!-- Header End -->