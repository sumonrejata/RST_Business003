<?php 

// Start Slider Title Custom Metabox

function Slider_Title_Metabox(){
	add_meta_box(
		'slider_title',
		'Slider Metabox',
		'slider_call_back',
		'slider',
	);
}
add_action('add_meta_boxes','Slider_Title_Metabox');

function slider_call_back(){ ?>
	<p>
		<label>Slider Title One</label>
		<input class="widefat" type="text" name="slider_title_one" value="
		
		<?php echo get_post_meta(get_the_ID(), 'slider_title_one', true);?>">
	</p>
	<p>
		<label>Slider Title Two</label>
		<input class="widefat" type="text" name="slider_title_two" value="<?php echo get_post_meta(get_the_ID(), 'slider_title_two', true);?>">
	</p>
	<p>
		<label>Slider View Demo</label>
		<input class="widefat" type="text" name="slider_view_demo" value="<?php echo get_post_meta(get_the_ID(), 'slider_view_demo', true);?>">
	</p>
	<p>
		<label>Slider Find More</label>
		<input class="widefat" type="text" name="slider_find_more" value="<?php echo get_post_meta(get_the_ID(), 'slider_find_more', true);?>">
	</p>

<?php }

function Slider_Title_one_value_save(){
	update_post_meta(get_the_ID(), 'slider_title_one', $_POST['slider_title_one']);
	update_post_meta(get_the_ID(), 'slider_title_two', $_POST['slider_title_two']);
	update_post_meta(get_the_ID(), 'slider_view_demo', $_POST['slider_view_demo']);
	update_post_meta(get_the_ID(), 'slider_find_more', $_POST['slider_find_more']);
}
add_action('save_post', 'Slider_Title_one_value_save');


// Start Home About custom Metabox

function Home_About_meatbox(){
	add_meta_box(
		'about_sub_title',
		'About Sub Title Metabox',
		'about_sub_title_callback',
		'about',
	);
}
add_action('add_meta_boxes','Home_About_meatbox');

function about_sub_title_callback(){ ?>
	<p>
		<label>About Sub Title One</label>
		<input class="widefat" type="text" name="about_sub_title_1" value="<?php echo get_post_meta(get_the_ID(), 'about_sub_title_1', true);?>">
	</p>
	<p>
		<label>About Sub Title Two</label>
		<input class="widefat" type="text" name="about_sub_title_2" value="<?php echo get_post_meta(get_the_ID(), 'about_sub_title_2', true);?>">
	</p>
	<p>
		<label>About Sub Title Three</label>
		<input class="widefat" type="text" name="about_sub_title_3" value="<?php echo get_post_meta(get_the_ID(), 'about_sub_title_3', true);?>">
	</p>
	<p>
		<label>About Sub Title Four</label>
		<input class="widefat" type="text" name="about_sub_title_4" value="<?php echo get_post_meta(get_the_ID(), 'about_sub_title_4', true);?>">
	</p>
	<p>
		<label>About Read More</label>
		<input class="widefat" type="text" name="about_read_more_btn" value="<?php echo get_post_meta(get_the_ID(), 'about_read_more_btn', true);?>">
	</p>
<?php }

function Home_About_Value_Save(){
	update_post_meta(get_the_ID(), 'about_sub_title_1', $_POST['about_sub_title_1']);
	update_post_meta(get_the_ID(), 'about_sub_title_2', $_POST['about_sub_title_2']);
	update_post_meta(get_the_ID(), 'about_sub_title_3', $_POST['about_sub_title_3']);
	update_post_meta(get_the_ID(), 'about_sub_title_4', $_POST['about_sub_title_4']);
	update_post_meta(get_the_ID(), 'about_read_more_btn', $_POST['about_read_more_btn']);
}
add_action('save_post','Home_About_Value_Save');


// Start Our Services Icon button metabox
function Our_Services_Icon_Metabox(){
	add_meta_box(
	'our_service',
	'Our Service Icon Metabox',
	'our_service_callback',
	'our_services',
	);
}
add_action('add_meta_boxes','Our_Services_Icon_Metabox');

function our_service_callback(){ ?>
	<p>
		<label>Enter Your Service Icon</label>
		<input class="widefat" type="text" name="service_icon" value="<?php echo get_post_meta(get_the_ID(),'service_icon', true);?>">
	</p>
<?php }

function Servicess_Icon_Value_Save(){
	update_post_meta(get_the_ID(),'service_icon', $_POST['service_icon']);
}
add_action('save_post','Servicess_Icon_Value_Save');


// Start Our Best Team Custom Metabox

function Our_Best_Team_MetaBox(){
	add_meta_box(
	'ourbestteam',
	'Our Best Team Metabox',
	'ourbestteam_call_back',
	'ourteam',
	);
	
}
add_action('add_meta_boxes','Our_Best_Team_MetaBox');

function ourbestteam_call_back(){ ?>
	<p>
		<label>Our Best Team Designation</label>
		<input class="widefat" type="text" name="our_best_team_desig" value="<?php echo get_post_meta(get_the_ID(), 'our_best_team_desig', true);?>">
	</p>

<?php }

function Our_Best_Team_Save_Value(){
	update_post_meta(get_the_ID(), 'our_best_team_desig', $_POST['our_best_team_desig']);
}
add_action('save_post','Our_Best_Team_Save_Value');

// Start Our Best Team Social Icon Metabox
function Our_Best_Team_Social_MetaBox(){
	add_meta_box(
		'ourbestsocial_icon',
		'Our Team Social icon Metabox',
		'ourbestsocial_icon_call_back',
		'ourteam',
	);
}
add_action('add_meta_boxes','Our_Best_Team_Social_MetaBox');

function ourbestsocial_icon_call_back(){ ?>
	<p>
		<label>Our Team Facebook Icon</label>
		<input class="widefat" type="text" name="ourteam_facebook" value="<?php echo get_post_meta(get_the_ID(),'ourteam_facebook', true);?>">
	</p>
	<p>
		<label>Our Team Facebook Link</label>
		<input class="widefat" type="text" name="ourteam_facebook_link" value="<?php echo get_post_meta(get_the_ID(),'ourteam_facebook_link', true);?>">
	</p>
	<p>
		<label>Our Team Twitter Icon</label>
		<input class="widefat" type="text" name="ourteam_twitter" value="<?php echo get_post_meta(get_the_ID(),'ourteam_twitter', true);?>">
	</p>
	<p>
		<label>Our Team Twitter Link</label>
		<input class="widefat" type="text" name="ourteam_twitter_link" value="<?php echo get_post_meta(get_the_ID(),'ourteam_twitter_link', true);?>">
	</p>
	<p>
		<label>Our Team Linkdin Icon</label>
		<input class="widefat" type="text" name="ourteam_linkdin" value="<?php echo get_post_meta(get_the_ID(),'ourteam_linkdin', true);?>">
	</p>
	<p>
		<label>Our Team Linkdin Link</label>
		<input class="widefat" type="text" name="ourteam_linkdin_link" value="<?php echo get_post_meta(get_the_ID(),'ourteam_linkdin_link', true);?>">
	</p>
	<p>
		<label>Our Team Google Icon</label>
		<input class="widefat" type="text" name="ourteam_google" value="<?php echo get_post_meta(get_the_ID(),'ourteam_google', true);?>">
	</p>
	<p>
		<label>Our Team Google Link</label>
		<input class="widefat" type="text" name="ourteam_google_link" value="<?php echo get_post_meta(get_the_ID(),'ourteam_google_link', true);?>">
	</p>
<?php }

function Our_Best_Team_Social_Icon_Save_Value(){
	update_post_meta(get_the_ID(),'ourteam_facebook', $_POST['ourteam_facebook']);
	update_post_meta(get_the_ID(),'ourteam_facebook_link', $_POST['ourteam_facebook_link']);
	update_post_meta(get_the_ID(),'ourteam_twitter', $_POST['ourteam_twitter']);
	update_post_meta(get_the_ID(),'ourteam_twitter_link', $_POST['ourteam_twitter_link']);
	update_post_meta(get_the_ID(),'ourteam_linkdin', $_POST['ourteam_linkdin']);
	update_post_meta(get_the_ID(),'ourteam_linkdin_link', $_POST['ourteam_linkdin_link']);
	update_post_meta(get_the_ID(),'ourteam_google', $_POST['ourteam_google']);
	update_post_meta(get_the_ID(),'ourteam_google_link', $_POST['ourteam_google_link']);
}
add_action('save_post','Our_Best_Team_Social_Icon_Save_Value');

// Start Counter Metabox Section
function Business_Counter_MetaBox(){
	add_meta_box(
		'counter_metabox_id',
		'Counter MetaBox',
		'counter_metabox_Call_back',
		'counter',
	);
}
add_action('add_meta_boxes','Business_Counter_MetaBox');

function counter_metabox_Call_back(){ ?>
	<p>
		<label>Enter Your Counter Icon</label>
		<input class="widefat" type="text" name="counter_icon" value="<?php echo get_post_meta(get_the_ID(),'counter_icon', true);?>">
	</p>
	<p>
		<label>Enter Your Counter Number</label>
		<input class="widefat" type="text" name="counter_number" value="<?php echo get_post_meta(get_the_ID(),'counter_number', true);?>">
	</p>
<?php }

function Business_Counter_MetaBox_Save_Value(){
	update_post_meta(get_the_ID(),'counter_icon', $_POST['counter_icon']);
	update_post_meta(get_the_ID(),'counter_number', $_POST['counter_number']);
}
add_action('save_post','Business_Counter_MetaBox_Save_Value');

// Start Pricing Table Custom Metabox
function Pricing_Table_Custom_MetaBocx(){
	add_meta_box(
		'pricingtable',
		'Pricing Table',
		'pricingtable_call_back',
		'pricing',
	);
}
add_action('add_meta_boxes','Pricing_Table_Custom_MetaBocx');
function pricingtable_call_back(){ ?>
	<p>
		<label>Pricing Amount</label>
		<input class="widefat" type="text" name="pricing_amount" value="<?php echo get_post_meta(get_the_ID(),'pricing_amount', true);?>">
	</p>
	<p>
		<label>Pricing Monthly</label>
		<input class="widefat" type="text" name="pricing_monthly" value="<?php echo get_post_meta(get_the_ID(),'pricing_monthly', true);?>">
	</p>
	<p>
		<label>Pricing Sub Title One</label>
		<input class="widefat" type="text" name="pricing_title_1" value="<?php echo get_post_meta(get_the_ID(),'pricing_title_1', true);?>">
	</p>
	<p>
		<label>Pricing Sub Title Two</label>
		<input class="widefat" type="text" name="pricing_title_2" value="<?php echo get_post_meta(get_the_ID(),'pricing_title_2', true);?>">
	</p>
	<p>
		<label>Pricing Sub Title Three</label>
		<input class="widefat" type="text" name="pricing_title_3" value="<?php echo get_post_meta(get_the_ID(),'pricing_title_3', true);?>">
	</p>
	<p>
		<label>Pricing Sub Title Four</label>
		<input class="widefat" type="text" name="pricing_title_4" value="<?php echo get_post_meta(get_the_ID(),'pricing_title_4', true);?>">
	</p>
	<p>
		<label>Pricing Sub Title Five</label>
		<input class="widefat" type="text" name="pricing_title_5" value="<?php echo get_post_meta(get_the_ID(),'pricing_title_5', true);?>">
	</p>
	<p>
		<label>Pricing Sub Title Six</label>
		<input class="widefat" type="text" name="pricing_title_6" value="<?php echo get_post_meta(get_the_ID(),'pricing_title_6', true);?>">
	</p>
	<p>
		<label>Pricing Button Text</label>
		<input class="widefat" type="text" name="pricing_btn_text" value="<?php echo get_post_meta(get_the_ID(),'pricing_btn_text', true);?>">
	</p>
	<p>
		<label>Pricing Table Active</label>
		<input class="widefat" type="text" name="pricing_tabel_active" value="<?php echo get_post_meta(get_the_ID(),'pricing_tabel_active', true);?>">
	</p>
<?php }
function Pricing_Table_Custom_MetaBocx_Save_Value(){
	update_post_meta(get_the_ID(),'pricing_amount', $_POST['pricing_amount']);
	update_post_meta(get_the_ID(),'pricing_monthly', $_POST['pricing_monthly']);
	update_post_meta(get_the_ID(),'pricing_title_1', $_POST['pricing_title_1']);
	update_post_meta(get_the_ID(),'pricing_title_2', $_POST['pricing_title_2']);
	update_post_meta(get_the_ID(),'pricing_title_3', $_POST['pricing_title_3']);
	update_post_meta(get_the_ID(),'pricing_title_4', $_POST['pricing_title_4']);
	update_post_meta(get_the_ID(),'pricing_title_5', $_POST['pricing_title_5']);
	update_post_meta(get_the_ID(),'pricing_title_6', $_POST['pricing_title_6']);
	update_post_meta(get_the_ID(),'pricing_btn_text', $_POST['pricing_btn_text']);
	update_post_meta(get_the_ID(),'pricing_tabel_active', $_POST['pricing_tabel_active']);
}
add_action('save_post', 'Pricing_Table_Custom_MetaBocx_Save_Value');

// Start Portfoli section Button Metabox

function Business_Portfoli_MetaBox(){
	add_meta_box(
		'portfolio_metabox_id',
		'Portfolio Meta Box',
		'portfolio_metabox_call_back',
		'portfolio',
	);
}
add_action('add_meta_boxes','Business_Portfoli_MetaBox');

function portfolio_metabox_call_back(){ ?>
	<p>
		<label>Enter Your Portfolio Button Text</label>
		<input class="widefat" type="text" name="portfolio_btn" value="<?php echo get_post_meta(get_the_ID(),'portfolio_btn', true);?>">
	</p>
<?php }

function Business_Portfolio_Save_Value(){
	update_post_meta(get_the_ID(), 'portfolio_btn', $_POST['portfolio_btn']);
}
add_action('save_post','Business_Portfolio_Save_Value');

// 

function Business_Blog_MetaBox(){
	add_meta_box(
		'blog_read_more_metabox',
		'Blog Read More Meta Box',
		'blog_metabox_call_back',
		'post',
	);
}
add_action('add_meta_boxes','Business_Blog_MetaBox');

function blog_metabox_call_back(){ ?>
	<p>
		<label>Enter Your Portfolio Button Text</label>
		<input class="widefat" type="text" name="blog_read_more_btn" value="<?php echo get_post_meta(get_the_ID(),'blog_read_more_btn', true);?>">
	</p>
<?php }

function Business_Read_More_Save_Value(){
	update_post_meta(get_the_ID(), 'blog_read_more_btn', $_POST['blog_read_more_btn']);
}
add_action('save_post','Business_Read_More_Save_Value');