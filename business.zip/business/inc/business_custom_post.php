<?php 
// Start Slider Post Type

function Business_Custom_Post_type(){
	register_post_type('slider', array(
		'labels' 				=>array(
			'name' 				=> __('slider','business'),
			'menu_name' 		=> __('Slider','business'),
			'add_new' 			=> __('Add New Slider','business'),
			'add_new_item' 		=> __('Add New Slider','business'),
			'edit_item' 		=> __('Edit Slider Item','business'),
			'all_items' 		=> __('All Slider','business'),
		),
		'public' 				=> true,
		'supports' 				=>array('title', 'editor', 'thumbnail'),
		'menu_icon' 			=>'dashicons-format-gallery', 	
	));


	register_post_type('about', array(
		'labels' 				=>array(
			'name' 				=>__('About', 'business'), 
			'menu_name' 		=>__('About Us', 'business'), 
			'add_new' 			=>__('Add New About', 'business'), 
			'add_new_item' 		=>__('Add New About Item', 'business'), 
			'edit_item' 		=>__('Edit About', 'business'), 
			'all_items' 		=>__('All About', 'business'), 
		),
		'public' 				=>true,
		'supports' 				=>array('title','editor','thumbnail'), 
		'menu_icon' 			=>'dashicons-admin-users', 			
	));


	register_post_type('our_services',array(
		'labels' 				=>array(
			'name' 				=>__('Services', 'business'), 
			'menu_name' 		=>__('Services', 'business'), 
			'add_new' 			=>__('Add New Services', 'business'), 
			'add_new_item' 		=>__('Add Services Items', 'business'), 
			'edit_item' 		=>__('Edit Services Items', 'business'), 
			'all_items' 		=>__('All Services', 'business'), 
		),
		'public' 				=>true,
		'menu_icon' 			=>'dashicons-admin-tools', 
		'supports' 				=>array('title','editor'),
	));


	register_post_type('ourteam', array(
		'labels' 				=> array(
			'name' 				=> __('Our Best Team','business'),
			'menu_name' 		=> __('Our Best Team','business'),
			'add_new' 			=> __('Add New Our Team','business'),
			'add_new_item' 		=> __('Add New Team','business'),
			'edit_item' 		=> __('Edit Our Best Team','business'),
			'all_items' 		=> __('All Our Best Team','business'),
		),
		'public' 				=> true,
		'supports' 				=> array('title','thumbnail','editor'),
		'menu_icon' 			=> 'dashicons-admin-users',
	));

	register_post_type('counter',array(
		'labels' 				=> array(
			'name' 				=>__('Counter','business'),
			'menu_name' 		=>__('Counter','business'),
			'add_new' 			=>__('Add New Counter','business'),
			'add_new_item' 		=>__('Add New Counter Item','business'),
			'edit_item' 		=>__('Edit Counter Item','business'),
			'all_items' 		=>__('All Counter Item','business'),
		),
		'public' => true,
		'supports' => array('title'),
		'menu_icon' => 'dashicons-money',
	));

	register_post_type('pricing',array(
		'labels' 				=> array(
			'name' 				=> __('Pricing','business'),
			'menu_name' 		=> __('Pricing','business'),
			'add_new' 			=> __('Add New Pricing','business'),
			'add_new_item' 		=> __('Add New Pricing Item','business'),
			'edit_item' 		=> __('Edit Pricing Item','business'),
			'all_items' 		=> __('All Pricing','business'),
		),
		'public' => true,
		'supports' => array('title'),
		'menu_icon' => 'dashicons-cart',
	));	

	register_post_type('testimonial',array(
		'labels' 				=> array(
			'name' 				=> __('Testimonial','business'),
			'menu_name' 		=> __('Testimonial','business'),
			'add_new' 			=> __('Add New Testimonial','business'),
			'add_new_item' 		=> __('Add New Testimonial Item','business'),
			'edit_item' 		=> __('Edit Testimonial Item','business'),
			'all_items' 		=> __('All Testimonial','business'),
		),
		'public' => true,
		'supports' => array('title','editor','thumbnail'),
		'menu_icon' => 'dashicons-admin-generic',
	));

	register_post_type('clients',array(
		'labels' 				=> array(
			'name' 				=>__('Clients', 'business'), 
			'menu_name' 		=>__('Clients', 'business'), 
			'add_new' 			=>__('Add New Clients', 'business'), 
			'add_new_item' 		=>__('Add Clients Item', 'business'), 
			'edit_item' 		=>__('Edit Clients', 'business'), 
			'all_items' 		=>__('All Clients', 'business'), 
		),
		'public' 				=> true,
		'supports' 				=> array('title','thumbnail'),
		'menu_icon' 			=>'dashicons-groups',
	));

	register_post_type('portfolio',array(
		'labels' 				=> array(
			'name' 				=>__('Portfolio', 'business'), 
			'menu_name' 		=>__('Portfolio', 'business'), 
			'add_new' 			=>__('Add New Portfolio', 'business'), 
			'add_new_item' 		=>__('Add Portfolio Item', 'business'), 
			'edit_item' 		=>__('Edit Portfolio', 'business'), 
			'all_items' 		=>__('All Portfolio', 'business'), 
		),
		'public' 				=> true,
		'supports' 				=> array('title','thumbnail'),
		'menu_icon' 			=>'dashicons-admin-media',
	));
	register_taxonomy('portfolios',
		array('portfolio'),
		array(
			'labels' => $labels,
			'hierarchical' => true,
			'show_ui' => true,
			'query_var' => true,
			'rewrite' => array('slug' =>'portfolios'),
		)
	);

	// $args = array(
	// 	'labels'                     => $labels,
	// 	'hierarchical'               => true,
	// 	'public'                     => true,
	// 	'show_ui'                    => true,
	// 	'query_var'                  => true,
	// 	 'show_admin_column'         => true,
	// 	'show_in_nav_menus'          => true,
	// 	'show_tagcloud'              => true,

	// );
	// register_taxonomy( 'portfol', array( 'slug' =>'portfol' ), $args );


}
add_action('init','Business_Custom_Post_type');

