<?php

class Business_Recent_Post extends WP_Widget{
 	public function __construct(){
 		parent::__construct(
 			'business_recent_post',
 			'Business Recent Post',
 			array('description'=>'Business Recent Custom Post Type Widget')
 		);

 		 add_action( 'widgets_init', function() {
            register_widget( 'Business_Recent_Post' );
        });

	} 

	// public $args = array(
 //        'before_title'  => '<h3>',
 //        'after_title'   => '</h3>',
 //        'before_widget' => '<div class="widget recent-posts-widget">',
 //        'after_widget'  => '</div>'
 //    );

    public function widget( $args, $instance ) { ?>
    	<?php echo $args['before_widget'];?>
    	<?php if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }?>
    		<?php 
    			$bu_recent_post = null;
    			$bu_recent_post = new WP_Query(array(
    				'post_type' => 'post',
    				'post_per_page' => -1,
    				'orderby' => 'ASC',
    			));
    			if ($bu_recent_post->have_posts()) {
    				while ($bu_recent_post->have_posts()) {
    					$bu_recent_post->the_post(); ?>
    					<div class="post">
    						<h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
    						<span class="date"><?php the_time( 'F j, Y' ); ?></span>
    					</div>
    				<?php }
    			}
    		?>
    		

    	<?php echo $args['after_widget'];?>
 
 
    <?php }

    public function form($instance){
    	      $title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'text_domain' );
        $text = ! empty( $instance['text'] ) ? $instance['text'] : esc_html__( '', 'text_domain' );
        ?>
        <p>
        <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Recent Post Title:', 'text_domain' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <?php
    }

}
$object = new Business_Recent_Post();