<?php 
function Business_Custom_widget(){
	 register_sidebar( array(
        'name'          => __( 'Business Catagory widget', 'business' ),
        'id'            => 'catagory_post_widget',
        'before_widget' => '<div class="widget categories-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) ); 

	 register_sidebar( array(
        'name'          => __( 'Recent Post', 'business' ),
        'id'            => 'recent_post',
        'before_widget' => '<div class="widget recent-posts-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );
     register_sidebar( array(
        'name'          => __( 'Tag Cloud', 'business' ),
        'id'            => 'tag_cloud',
        'before_widget' => '<div class="widget tags-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) ); 
     register_sidebar( array(
        'name'          => __( 'Serch Box', 'business' ),
        'id'            => 'serach_box',
        'before_widget' => '<div class="widget search-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );
}
add_action('widgets_init','Business_Custom_widget');


    


