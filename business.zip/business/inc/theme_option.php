<?php 

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

  //
  // Set a unique slug-like ID
  $prefix = 'business';

  //
  // Create options
  CSF::createOptions( $prefix, array(
    'menu_title' => 'Theme Options',
    'menu_slug'  => 'theme_options',
  ) );

  //
  // Create a section
  CSF::createSection( $prefix, array(
    'title'  => 'Header Options',
    'fields' => array(

      //
      // A text field
      array(
        'id'      =>'phone_n',
        'type'    =>'text',
        'title'   =>'Phome Number',
        'default' => '01537-472075',
      ),

      array(
      	'id'   	   =>'header_email', 	
      	'type'     =>'text', 	
      	'title' 	 =>'Header Email', 
        'default'  => 'Tanjim@gmail.com',	
      ),

// Start header social icon section 

      array(
      	'id' 	    =>'facebook_icon', 	
      	'type'    =>'text', 	
      	'title' 	=>'Facebook Icon',
        'default' => 'facebook',	
      ),
      array(
        'id'      =>'facebook_link',  
        'type'    =>'text',   
        'title'   =>'Facebook Link',
        'default' => 'https://www.facebook.com',     
      ),

      array(
      	'id' 		  => 'twitter_icon',
      	'title' 	=> 'Twitter Icon',
      	'type' 		=> 'text',
        'default' => 'twitter', 
      ),
      array(
        'id'      => 'twitter_link',
        'title'   => 'Twitter Link',
        'type'    => 'text',
        'default' => 'https://twitter.com', 
      ),
      array(
        'id'      => 'linkedin_icon',
        'title'   => 'Linkedin icon',
        'type'    => 'text',
        'default' => 'linkedin',
      ), 
      array(
        'id'      => 'linkedin_link',
        'title'   => 'Linkedin Link',
        'type'    => 'text',
        'default' => 'https://www.linkedin.com',
      ), 
      array(
        'id'      => 'pinterest_icon',
        'title'   => 'Pinterest Icon',
        'type'    => 'text',
        'default' => 'pinterest-p',
      ), 
      array(
        'id'      => 'pinterest_link',
        'title'   => 'Pinterest Link',
        'type'    => 'text',
        'default' => 'https://www.pinterest.com',
      ),
      array(
        'id'      => 'instagram_icon',
        'title'   => 'Instagram Icon',
        'type'    => 'text',
        'default' => 'instagram',
      ), 
      array(
        'id'      => 'instagram_link',
        'title'   => 'Instagram Link',
        'type'    => 'text',
        'default' => 'https://www.instagram.com',
      ),
      array(
        'id'      => 'google_plus_icon',
        'title'   => 'google-plus Icon',
        'type'    => 'text',
        'default' => 'google-plus',
      ), 
      array(
        'id'      => 'google_plus_link',
        'title'   => 'google-plus Link',
        'type'    => 'text',
        'default' => 'https://www.google.com',
      ),
      array(
        'id'      => 'youtube_play_icon',
        'title'   => 'youtube-play Icon',
        'type'    => 'text',
        'default' => 'youtube-play',
      ), 
      array(
        'id'      => 'youtube_play_link',
        'title'   => 'google-plus Link',
        'type'    => 'text',
        'default' => 'https://www.youtube.com',
      ),


    )
  ) );


// Start header social icon section 

CSF::createSection($prefix, array(
   'title'     =>'Header Logo',
  'fields'     =>array(
    // Start Header Logo section field
    array(
      'id'        =>'header_logo_1',
      'title'     =>'Header Logo Text One',
      'type'      =>'text', 
      'default'   => 'LO',
    ),
    array(
      'id'        =>'header_logo_2',
      'title'     =>'Header Logo Text Two',
      'type'      =>'text', 
      'default'   => 'GO',
    ),
  )
));

// Start Home About Title Section

CSF::createSection($prefix,array(
  'title'     => 'About Title',
  'fields'    =>array(
// Home About title field 
    array(
      'id'      => 'about_title_1',
      'type'    => 'text',
      'title'   => 'About Title One',
      'default' => 'About',
    ),
    array(
      'id'      => 'about_title_2',
      'type'    => 'text',
      'title'   => 'About Title two',
      'default' => 'Us',
    ),
  ) 
)); 

// Start Home Service Section Function

CSF::createSection($prefix,array(
  'title'       => 'Service Title One',
  'fields'      =>array(
    // start service field
    array(
      'id'      =>'service_title_1',
      'title'   =>'Service Title One',
      'type'    =>'text',
      'default' => 'Our',
    ),
    array(
      'id'      =>'service_title_2',
      'title'   =>'Service Title Two',
      'type'    =>'text',
      'default' => 'Services',
    ),
  ) 
));

// Start Our Best Team Section Title
CSF::createSection($prefix,array(
  'title'       => 'Our Best Team',
  'fields'      => array(
    array(
      'id'       => 'our_best_team_1',
      'title'    => 'Our Best',
      'type'     => 'text',
      'default'  => 'Our Best',
    ),
    array(
      'id'       => 'our_best_team_2',
      'title'    => 'Team',
      'type'     => 'text',
      'default'  => 'Team',
    ), 
    array(
      'id'       => 'ourteam_icon',
      'title'    => 'Our Best Team Icon',
      'type'     => 'text',
      'default'  => 'diamond',
    )
  )
)); 

// Start Counter Section Background Image

CSF::createSection($prefix,array(
  'title'         => 'Counter Background',
  'fields'        => array(
    array(
      'id'        => 'counter_bg',
      'type'      => 'media',
      'title'     => 'Select Counter Background Image',
    ),
  )
));

// Start Pricing Table Title Section 
CSF::createSection($prefix,array(
  'title'   => 'Pricing Title',
  'fields'  => array(
    array(
      'id'      => 'pricing_title_1',
      'title'   => 'Pricing Title One',
      'type'    => 'text',
      'default' => 'Pricing',
    ),
    array(
      'id'      => 'pricing_title_2',
      'title'   => 'Pricing Title Two',
      'type'    => 'text',
      'default' => 'Table',
    ), 
    array(
      'id'      => 'pricing_title_icon',
      'title'   => 'Pricing Title Icon',
      'type'    => 'text',
      'default' => 'diamond',
    )
  )
));

// Start Footer Social Media Section

CSF::createSection($prefix,array(
  'title'     => 'Footer Social Icon',
  'fields'    => array(
    array(
      'id'      => 'foot_fac_icon',
      'title'   => 'Footer Facebook Icon',
      'type'    => 'text',
      'default' => 'facebook',
    ),
    array(
      'id'      => 'foot_fac_ic_link',
      'title'   => 'Footer Facebook Icon Link',
      'type'    => 'text',
      'default' => 'https://www.facebook.com',
    ),
    array(
      'id'      => 'foot_link_icon',
      'title'   => 'Footer Linkedin Icon',
      'type'    => 'text',
      'default' => 'linkedin',
    ),
    array(
      'id'      => 'foot_link_icon_link',
      'title'   => 'Footer Linkedin Icon Link',
      'type'    => 'text',
      'default' => 'https://www.linkedin.com',
    ), 
    array(
      'id'      => 'foot_twitter_icon',
      'title'   => 'Footer Twitter Icon',
      'type'    => 'text',
      'default' => 'twitter',
    ),
    array(
      'id'      => 'foot_twiter_icon_link',
      'title'   => 'Footer Twitter Icon Link',
      'type'    => 'text',
      'default' => 'https://twitter.com',
    ),
    array(
      'id'      => 'foot_pinterest_icon',
      'title'   => 'Footer Pinterest Icon',
      'type'    => 'text',
      'default' => 'pinterest-p',
    ),
    array(
      'id'      => 'foot_pinterest_icon_link',
      'title'   => 'Footer Pinterest Icon Link',
      'type'    => 'text',
      'default' => 'https://www.pinterest.com',
    ), 
    array(
      'id'      => 'foot_instagram_icon',
      'title'   => 'Footer Instagram Icon',
      'type'    => 'text',
      'default' => 'instagram',
    ),
    array(
      'id'      => 'foot_instagram_icon_link',
      'title'   => 'Footer Instagram Icon Link',
      'type'    => 'text',
      'default' => 'https://www.instagram.com',
    ),
    array(
      'id'      => 'foot_google_plus_icon',
      'title'   => 'Footer google-Plus Icon',
      'type'    => 'text',
      'default' => 'google-plus',
    ),
    array(
      'id'      => 'foot_google_plus_link',
      'title'   => 'Footer google-plus Icon Link',
      'type'    => 'text',
      'default' => 'https://www.google.com',
    ),

     array(
      'id'       => 'foot_youtube_icon',
      'title'    => 'Footer YouTube Icon',
      'type'     => 'text',
      'default'  => 'youtube-play',
    ),
    array(
      'id'      => 'foot_youtube_link',
      'title'   => 'Footer YouTube Icon Link',
      'type'    => 'text',
      'default' => 'https://www.google.com',
    ),
    array(
      'id'      => 'footer_fopy_write',
      'title'   => 'Footer Copyright Text',
      'type'    => 'textarea',
      'default' => '© Copyright 2018. All Rights Reserved. Designed by',
    ),
    array(
      'id'      => 'footer_fopy_wri_link',
      'title'   => 'Footer Copyright Link',
      'type'    => 'wp_editor',
      'default' => 'Md.Tanjim Ahamed',
    ),
  )
));

// Start Testimonial Title Section

CSF::createSection($prefix,array(
  'title'   => 'Testimonial Title',
  'fields'  => array(
    array(
      'id'      =>'testimonial_1',
      'title'   => 'Testimonial Title One',
      'type'    => 'text',
      'default' => 'WHAT',
    ),
    array(
      'id'      =>'testimonial_2',
      'title'   => 'Testimonial Title Two',
      'type'    => 'text',
      'default' => 'CLIENT',
    ),
    array(
      'id'      =>'testimonial_3',
      'title'   => 'Testimonial Title Three',
      'type'    => 'text',
      'default' => 'SAY',
    ),
  )
));

// Start About Page Breadcumb Section
CSF::createSection($prefix,array(
  'title'   => 'Page Breadcrumb',
  'fields'  => array(
    array(
      'id'    =>'about_page_bread', 
      'title' => 'Select About Page Breadcrumb Image',
      'type'  =>'media', 
    ),
    array(
      'id'    =>'service_page_bread', 
      'title' => 'Select Service Page Breadcrumb Image',
      'type'  =>'media', 
    ),
    array(
      'id'    =>'portfolio_page_bread', 
      'title' => 'Select Portfolio Page Breadcrumb Image',
      'type'  =>'media', 
    ),
    array(
      'id'    =>'blog_page_bread', 
      'title' => 'Select Blog Page Breadcrumb Image',
      'type'  =>'media', 
    ),
  )
));
































}