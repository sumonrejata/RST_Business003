    <?php 
    /*
        Template Name: Home
    */
?>
    <?php get_header();?>

     <!-- == Home Section Start == -->
    <section id="home" >
        <!-- == Color schemes == -->
    	  <div class="color-schemes">
    	  	 <div class="color-handle">
                 <i class="fa fa-cogs fa-spin" aria-hidden="true"></i>
    	  	 </div>
    	  	 <div class="color-plate">
      		     <h5>Chose color</h5>
    		       <a href="css/colors/defaults-color.css" class="single-color defaults-color">Defaults</a>
               <a href="css/colors/red-color.css" class="single-color red-color">Red</a>
               <a href="css/colors/purple-color.css" class="single-color purple-color">Purple</a>
               <a href="css/colors/sky-color.css" class="single-color sky-color">sky</a>
               <a href="css/colors/green-color.css" class="single-color green-color">Green</a>
               <a href="css/colors/blue-color.css" class="single-color pink-color">Pink</a>
    	  	  </div>
    	  </div>
        <!-- == /Color schemes == -->	
        <!-- silider start -->
        <div class="main-slider-1 white-clr-all">
          <div id="carosel-mr-1" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carosel-mr-1" data-slide-to="0" class="active"></li>
              <li data-target="#carosel-mr-1" data-slide-to="1"></li>
              <li data-target="#carosel-mr-1" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner main-sld" role="listbox">

              <?php
              $slider = null;
              $slider = new WP_query(array(
                'post_type' => 'slider',
                'posts_per_page' => -1,
              ));
              if( $slider->have_posts() ){
                 $x =0;
                while ($slider->have_posts() ){
                  $x++;
                  $slider->the_post();
                  $slider_title_one = get_post_meta(get_the_ID(), 'slider_title_one', true);
                  $slider_title_two = get_post_meta(get_the_ID(), 'slider_title_two', true);
                  $slider_view_demo = get_post_meta(get_the_ID(), 'slider_view_demo', true);
                  $slider_find_more = get_post_meta(get_the_ID(), 'slider_find_more', true);
                  $backgroundImg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
                  ?>

                  <div class="item <?php if($x==1){ echo 'active'; } ?> main-sld">
                    <!-- change slider image -->
                    <div class="slider-bg" style="background-image: url(<?php echo $backgroundImg[0]; ?>);">
                    </div>
                    <div class="slider-cell">
                      <div class="slider-ver">
                        <div class="slider-con text-center">

                          <?php if($slider_title_one) : ?>
                            <h1>
                              <?php echo $slider_title_one;?> <span><?php echo $slider_title_two;?></span>
                            </h1>
                          <?php endif;?>
                          <p><?php the_content();?></p>

                          <?php if($slider_view_demo) : ?>
                            <a class="btn btn-default btn-animate btn-style hvr-shutter-out-vertical" href="<?php the_permalink();?>"><?php echo $slider_view_demo;?> </a>
                          <?php endif;?>

                          <?php if($slider_find_more) : ?>
                            <a class="btn btn-default btn-animate btn-style hvr-shutter-out-vertical" href="<?php the_permalink();?>"><?php echo $slider_find_more;?></a>
                          <?php endif;?>
                        </div>
                        <!-- end slider content -->
                      </div>
                    </div>
                  </div>
                  <!-- end single item -->
                <?php }
              }
              else{
                echo "No Post";
              }
              wp_reset_postdata();
              ?> 
            </div>
            <a class="left slide-control-mr" href="#carosel-mr-1" role="button" data-slide="prev"><i class="fa fa-angle-left"></i></a>
            <a class="right slide-control-mr" href="#carosel-mr-1" role="button" data-slide="next"><i class="fa fa-angle-right"></i></a>
          </div>
        </div>
        <!-- end slider bar -->
        <!--slider section start-->	
    </section>
    <!-- == Home Section End == -->

    <?php get_template_part('templates/template','about'); ?>
    <?php get_template_part('templates/template', 'services'); ?>
    <?php get_template_part('templates/template', 'ourbestteam'); ?>
    <?php get_template_part('templates/template', 'counter'); ?>
    <?php get_template_part('templates/template', 'pricing'); ?>
    <?php get_template_part('templates/template', 'portfolio'); ?>
    

<?php get_footer(); ?>
