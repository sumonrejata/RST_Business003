
<form class="form" method="GET" action="<?php bloginfo('home'); ?>">
    <div>
        <input type="text" name="s" class="form-control" placeholder="Search...">
        <button type="submit" value="&#xf002"><i class="fa fa-search"></i></button>
    </div>
</form>
