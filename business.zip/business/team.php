<?php
    /*
    Template Name: Team
    */
 ?>
    <?php get_header();?>
    <!-- == Color schemes == -->
	  <div class="color-schemes">
	  	 <div class="color-handle">
             <i class="fa fa-cogs fa-spin" aria-hidden="true"></i>
	  	 </div>
	  	 <div class="color-plate">
	  		 <h5>Chose color</h5>
  		     <a href="css/colors/defaults-color.css" class="single-color defaults-color">Defaults</a>
             <a href="css/colors/red-color.css" class="single-color red-color">Red</a>
             <a href="css/colors/purple-color.css" class="single-color purple-color">Purple</a>
             <a href="css/colors/sky-color.css" class="single-color sky-color">sky</a>
             <a href="css/colors/green-color.css" class="single-color green-color">Green</a>
             <a href="css/colors/blue-color.css" class="single-color pink-color">Pink</a>
	  	  </div>
	  </div>
     <!-- == /Color schemes == -->
   <?php $servi_page_bread = get_option('business');?>
    <section class="page-title page-bg bg-opacity section-padding" style="background-image: url(<?php echo $servi_page_bread['service_page_bread']['url'];?>);">
    	<div class="container">
    		<div class="row">
    			<div class="col-md-12">
    				<h2><?php the_title();?></h2>
    				<div class="breadcrumb">
    					<ul>
    						<li><a href="<?php bloginfo('url');?>"><?php get_breadcrumb(); ?></a></li>
    						
    					</ul>
    				</div>
    			</div>
    		</div>
    	</div>
    </section>


<?php get_template_part('templates/template', 'ourbestteam'); ?>
<?php get_footer();?>
