<!-- == About Section Start == -->
    <section id="about" class="about section-padding-top">
    	<div class="container">
        <?php $about=get_option('business');?>
    		<div class="section-title">
    			<h2><?php echo $about['about_title_1'];?> <span><?php echo $about['about_title_2'];?></span>
          </h2>
    			<span class="s-title-icon"><i class="icofont icofont-diamond"></i></span>
    		</div>
        <?php
        $about = null;
        $about = new WP_query(array(
          'post_type' => 'about',
          'posts_per_page' => 1,
        ));
        if( $about->have_posts() ){
          while ($about->have_posts() ){
            $about->the_post();
            $backgroundImg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
            $about_sub_title_1 = get_post_meta(get_the_ID(),'about_sub_title_1', true);
            $about_sub_title_2 = get_post_meta(get_the_ID(),'about_sub_title_2', true);
            $about_sub_title_3 = get_post_meta(get_the_ID(),'about_sub_title_3', true);
            $about_sub_title_4 = get_post_meta(get_the_ID(),'about_sub_title_4', true);
            $about_read_more_btn = get_post_meta(get_the_ID(),'about_read_more_btn', true);
            ?>

            <div class="row">
              <!-- About image -->
              <div class="col-md-6">
                <a href="#" class="img-about">
                 <?php
                 if ( has_post_thumbnail() ) :
                  the_post_thumbnail('about');
                endif;
                ?>
                </a>
              </div>
              <div class="col-md-6">
                <!-- About text-->
                <div class="about-details">
                  <h5><?php the_title();?></h5>
                  <p><?php the_content();?></p>
                  <ul class="image-contact-list">
                    <li><i class="icofont icofont-speech-comments"></i> <span> <?php echo $about_sub_title_1;?></span></li>
                    <li><i class="icofont icofont-package"></i> <span><?php echo $about_sub_title_2;?></span></li>
                    <li><i class="icofont icofont-settings"></i> <span><?php echo $about_sub_title_3;?></span></li>
                    <li><i class="icofont icofont-gift"></i> <span><?php echo $about_sub_title_4;?></span></li>

                  </ul>
                  <a class="btn btn-default btn-style hvr-shutter-out-vertical" href="<?php the_permalink();?>"><?php echo $about_read_more_btn;?></a>
                </div>
                <!-- /About text -->
              </div>
            </div>


          <?php }
        }
        else{
          echo "No Post";
        }
        wp_reset_postdata();
        ?>
    	</div>
    </section>
    <!-- == About Section End == -->