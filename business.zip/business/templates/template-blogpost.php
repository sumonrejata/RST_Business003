  <div class="col col-lg-9">
                        <div class="blog-grids-s2 blog-content-wrapper">
                            <div class="row">
                                <?php 
                                    $blog_post = null;
                                    $blog_post = new WP_query(array(
                                        'post_type' => 'post',
                                        'post_per_page' => -1,
                                        'order' => 'ASC',
                                    ));
                                    if ($blog_post->have_posts()) {
                                        while ($blog_post->have_posts()) {
                                            $blog_post->the_post(); ?>
                                                 <div class="col-md-6 m-b-30">
                                    <div class="grid">
                                        <div class="entry-header">
                                            <?php if(has_post_thumbnail())
                                                the_post_thumbnail('blogpost');
                                            ?>
                                        </div>
                                        <div class="entry-body">
                                            <div class="entry-meta">
                                                <ul>
                                                    <li><i class="fa fa-user"></i>Post by: <a href="#"><?php echo get_the_author();?></a></li>
                                                    <li><i class="fa fa-calendar"></i> <a href="<?php the_permalink();?>"><?php the_time( 'd M, Y' ); ?></a></li>
                                                    <li><i class="fa fa-commenting"></i> <a href="#">10 Comments</a></li>
                                                </ul>
                                            </div>
                                            <div class="entry-details">
                                                <h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                                                <p><?php echo wp_trim_words(get_the_content(),30,'.....');?></p>
                                                <a href="<?php the_permalink();?>">Read More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                        <?php }
                                    }
                                    else{
                                        echo "You have no post";
                                    }
                                    wp_reset_postdata();
                                 ?>
                               

                            </div>
                        </div>
                        <div class="pagi m-t-0 text-center">
                            <ul>
                                <li>
                                    <a href="#"><i class="fa fa-long-arrow-left"></i></a>
                                </li>
                                <li class="active"><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li>
                                    <a href="#"><i class="fa fa-long-arrow-right"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>