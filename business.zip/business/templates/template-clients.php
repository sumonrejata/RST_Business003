<section class="clients bg-silver">
	<div class="container ptb-40 ">
		<div class="row">
			<div class="col-md-12">
				<div id="owl-clients-6" class="owl-carousel clients-logo text-center">
					<?php 
					$clients = null;
					$clients = new WP_query(array(
						'post_type' => 'clients',
						'post_per_page' => -1,
					));
					if ($clients->have_posts()) {
						while ($clients->have_posts()) {
							$clients->the_post(); ?>
							<div class="item">
								<a href="<?php the_permalink();?>"><?php if ( has_post_thumbnail() ) :
								the_post_thumbnail('clie');
								endif;?></a>
							</div>
						<?php }
					}
					else{
						echo "You have no post";
					}
					wp_reset_postdata();
					?>
				</div>
			</div>
		</div>
	</div>
</section>