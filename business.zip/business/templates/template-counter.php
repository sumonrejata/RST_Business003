<!-- == Counter Section Start == -->
    <?php $counte_bg = get_option('business');?>
    <section id="counter" class="counter-bg bg-opacity section-padding-60" style="background-image: url(<?php echo $counte_bg['counter_bg']['url'];?>);">
    	<div class="container">
    		<div class="row">
          <?php  
          $counter = null;
          $counter = new WP_query(array(
            'post_type'       => 'counter',
            'posts_per_page'  => 4,
            'order' =>'ASC',
          ));
          if ($counter->have_posts()) {
            while ($counter->have_posts()) {
              $counter->the_post(); 
              $counter_number = get_post_meta(get_the_ID(),'counter_number', true);
              $counter_icon = get_post_meta(get_the_ID(),'counter_icon', true);
              ?>
              <div class="col-md-3 col-sm-6">
                <div class="counter-item style-2">
                  <div class="counter-item-inner">
                    <?php if($counter_icon) : ?>
                      <i class="fa fa-<?php echo $counter_icon;?>" aria-hidden="true"></i>
                    <?php endif;?>
                    <h4><?php the_title();?></h4>
                    <?php if($counter_number) : ?>
                      <span class="counter">
                        <?php echo $counter_number;?>
                      </span>
                    <?php endif;?>
                  </div>
                </div>
              </div>
            <?php }
          }
          else{
            echo "You Have No Post";
          }
          wp_reset_postdata();
          ?>
        </div>
      </div>
    </section>
    <!-- == Counter Section End == -->