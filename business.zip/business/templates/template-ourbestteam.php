<!-- == Team Section Start == -->
    <section id="team" class="section-padding">
      <div class="container">
        <?php $ourbestteam = get_option('business');?>
        <div class="section-title">
          <?php if($ourbestteam['our_best_team_1']) : ?>
          <h2><?php echo $ourbestteam['our_best_team_1'];?> <span><?php echo $ourbestteam['our_best_team_2'];?></span>
          </h2>
        <?php endif;?>
        <?php if($ourbestteam['ourteam_icon']) : ?>
          <span class="s-title-icon"><i class="icofont icofont-<?php echo $ourbestteam['ourteam_icon'];?>"></i>
          </span>
        <?php endif;?>
         
        </div>
        <div class="row">
          <?php 
          $ourteam = null;
          $ourteam = new WP_query(array(
            'post_type' =>'ourteam',
            'posts_per_page' => -1,
            'order' => 'ASC',
          ));
          if ($ourteam->have_posts()) {
            while ($ourteam->have_posts() ){
              $ourteam->the_post(); 
              $ourteam_desig = get_post_meta(get_the_ID(), 'our_best_team_desig', true);
              $ourteam_facebook = get_post_meta(get_the_ID(), 'ourteam_facebook', true);
              $ourteam_facebook_link = get_post_meta(get_the_ID(), 'ourteam_facebook_link', true);
              $ourteam_twitter = get_post_meta(get_the_ID(), 'ourteam_twitter', true);
              $ourteam_twitter_link = get_post_meta(get_the_ID(), 'ourteam_twitter_link', true);
              $ourteam_linkdin = get_post_meta(get_the_ID(), 'ourteam_linkdin', true);
              $ourteam_linkdin_link = get_post_meta(get_the_ID(), 'ourteam_linkdin_link', true);
              $ourteam_google = get_post_meta(get_the_ID(), 'ourteam_google', true);
              $ourteam_google_link = get_post_meta(get_the_ID(), 'ourteam_google_link', true);
              ?>
                 <!-- Single team item-->  
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="team-single text-center m-b-30">
                    <div class="team-img">
                      <?php
                        if ( has_post_thumbnail() ) {
                          the_post_thumbnail('ourteam');
                        }
                      ?>
                        <ul>
                          <?php if($ourteam_facebook) : ?>
                            <li><a href="<?php echo $ourteam_facebook_link;?>"><i class="fa fa-<?php echo $ourteam_facebook;?>"></i></a>
                            </li>
                          <?php endif;?>

                          <?php if($ourteam_twitter) : ?>
                            <li><a href="<?php echo $ourteam_twitter_link;?>"><i class="fa fa-<?php echo $ourteam_twitter;?>"></i></a>
                            </li>
                          <?php endif;?>

                          <?php if($ourteam_linkdin) : ?>
                            <li><a href="<?php echo $ourteam_linkdin_link;?>"><i class="fa fa-<?php echo $ourteam_linkdin;?>"></i></a>
                            </li>
                          <?php endif;?>

                          <?php if($ourteam_google) : ?>
                            <li><a href="<?php echo $ourteam_google_link;?>"><i class="fa fa-<?php echo $ourteam_google;?>"></i></a>
                            </li>
                          <?php endif;?>
                        </ul>
                    </div>
                     <div class="team-content">
                        <h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                        <span><?php echo $ourteam_desig;?></span>
                    </div>
                </div>
            </div>
            <?php }
          }
          else{
            echo "You Have No Post";
          }
          wp_reset_postdata();
          ?>
        </div>
      </div>
    </section>
    <!-- == Team Section End == -->