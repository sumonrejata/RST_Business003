<!-- ==== Portfolio section start ==== -->
<section class="section-padding gray-brackground" id="portfolio">
	<div class="container">
		<div class="section-title">
			<h2>Our <span>Project</span></h2>
			<span class="s-title-icon"><i class="icofont icofont-diamond"></i></span>
		</div>
		<div class="portfolio-content">
			<!-- Protfolio navbar -->
			<div class="portfolio-filter-wrap text-center" >
				<ul class="portfolio-filter hover-style-one">
					<li class="active"><a href="#" data-filter="*"> All</a></li>
					<?php $port_cata = get_terms('portfolios');
					if (!empty($port_cata)) : foreach($port_cata as $port_catagorys) : ?>
						<li><a href="<?php the_permalink();?>" data-filter=".<?php echo $port_catagorys->slug;?>"><?php echo $port_catagorys->name;?></a></li>
					<?php endforeach; endif;?>

				</ul>
			</div>
			<div class="portfolio portfolio-gutter portfolio-style-2 portfolio-container portfolio-masonry portfolio-column-count-4 ">
				<!-- Single portfolio item -->
				<?php
				$portfolio = null;
				$portfolio = new WP_query(array(
					'post_type'      => 'portfolio',
					'posts_per_page' => -1,
					'order'          => 'ASC',
				));
				if( $portfolio->have_posts() ){
					while ($portfolio->have_posts() ){
						$portfolio->the_post();
						$portfolio_btn = get_post_meta(get_the_ID(),'portfolio_btn', true);
						?>

						<div class="portfolio-item <?php 
						$filter_item = get_the_terms(get_the_ID(), 'portfolios');
						if (!empty($filter_item)) : foreach ($filter_item as $filter_itesho) :
						echo $filter_itesho->slug.' ';
						endforeach; endif;
					?>">
					<div class="portfolio-item-content">
						<div class="item-thumbnail">
							<!-- Change the dummy image -->
							<?php if ( has_post_thumbnail() ) : 
								the_post_thumbnail('portfolio');
							endif;
							?>
						</div>
						<div class="portfolio-description">
							<h4><a href="<?php the_permalink();?>" ><?php the_title();?></a></h4>
							<?php $attachment_image = wp_get_attachment_url( get_post_thumbnail_id() ); ?>
							<!-- Change the dummy image -->
							<a href="<?php echo esc_url( $attachment_image ); ?>" class="portfolio-gallery-set"><i class="fa fa-search-plus"></i></a><a target="_blank" href="<?php the_permalink();?>"><i class="fa fa-link"></i></a>
						</div>                                    
					</div>
				</div>

			<?php }
		}
		else{
			echo "No Post";
		}
		wp_reset_postdata();

		?>
	</div>
	<?php if($portfolio_btn) : ?>         
	<div class="text-center">
		<a class="btn btn-default btn-style hvr-shutter-out-vertical" href="<?php the_permalink();?>"><?php echo $portfolio_btn; ?></a>
	</div> 
	<?php endif; ?>          
</div>	 
</div>
</section>
<!-- ==== Protfolio section end ==== -->