<!-- == Pricing Table Section Start == -->
<section id="portfolio-section" class="portfolio section-padding-top">
	<div class="container">
		<?php $pricing = get_option('business');?>
		<div class="section-title">
			<?php if($pricing['pricing_title_1']) : ?>
				<h2><?php echo $pricing['pricing_title_1'];?>
				<span>
					<?php echo $pricing['pricing_title_2'];?>
				</span>
			</h2>
		<?php endif;?>
		<?php if($pricing['pricing_title_icon']) : ?>
			<span class="s-title-icon"><i class="icofont icofont-<?php echo $pricing['pricing_title_icon'];?>"></i>
			</span>
		<?php endif;?>
	</div>
	<div class="row">
		<?php  
		$pricing = null;
		$pricing = new WP_query(array(
			'post_type' => 'pricing',
			'post_per_page' => -1,
			'order' => 'ASC',
		));
		if ($pricing->have_posts()) {
			while ($pricing->have_posts()) {
				$pricing->the_post(); 
				$pricing_amount = get_post_meta(get_the_ID(),'pricing_amount', true);
				$pricing_monthly = get_post_meta(get_the_ID(),'pricing_monthly', true);
				$pricing_title_1 = get_post_meta(get_the_ID(),'pricing_title_1', true);
				$pricing_title_2 = get_post_meta(get_the_ID(),'pricing_title_2', true);
				$pricing_title_3 = get_post_meta(get_the_ID(),'pricing_title_3', true);
				$pricing_title_4 = get_post_meta(get_the_ID(),'pricing_title_4', true);
				$pricing_title_5 = get_post_meta(get_the_ID(),'pricing_title_5', true);
				$pricing_title_6 = get_post_meta(get_the_ID(),'pricing_title_6', true);
				$pricing_btn_text = get_post_meta(get_the_ID(),'pricing_btn_text', true);
				$pricing_tabel_active = get_post_meta(get_the_ID(),'pricing_tabel_active', true);
				?>
				<div class="col-md-3">
					<div class="pricing-item text-center <?php echo $pricing_tabel_active;?>">
						<div class="pricing-heading">
							<h6 class="title"><?php the_title();?></h6>
						</div>
						<div class="pricing-body">
							<?php if($pricing_amount) : ?>
								<div class="rate">
									<h3 class="amount">$<?php echo $pricing_amount;?></h3>
									<h6 class="validity"><?php echo $pricing_monthly;?></h6>
								</div>
							<?php endif;?>
							<ul class="pricing-list">
								<?php if($pricing_title_1) : ?>
									<li><?php echo $pricing_title_1;?></li>
								<?php endif;?>
								<?php if($pricing_title_2) : ?>
									<li><?php echo $pricing_title_2;?></li>
								<?php endif;?>
								<?php if($pricing_title_3) : ?>
									<li><?php echo $pricing_title_3;?></li>
								<?php endif;?>
								<?php if($pricing_title_4) : ?>
									<li><?php echo $pricing_title_4;?></li>
								<?php endif;?>
								<?php if($pricing_title_5) : ?>
									<li><?php echo $pricing_title_5;?></li>
								<?php endif;?>
								<?php if($pricing_title_6) : ?>
									<li><?php echo $pricing_title_6;?></li>
								<?php endif;?>
							</ul>
							<a class="button btn btn-default btn-style hvr-shutter-out-vertical " href="<?php the_permalink();?>"><?php echo $pricing_btn_text;?></a>

						</div>
					</div>
				</div>
			<?php }
		}
		else{
			echo "You Have No Post";
		}
		wp_reset_postdata();
		?>        
	</div>
</div>
</section>
<!-- == Pricing Table Section End == -->