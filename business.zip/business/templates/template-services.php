<!-- == Service Section Start == -->
    <section id="service" class="service section-padding-top">
    	<div class="container">
        <?php $our_service = get_option('business');?>
    		<div class="section-title">
    			<h2><?php echo $our_service['service_title_1'];?> <span><?php echo $our_service['service_title_2'];?></span></h2>
    			<span class="s-title-icon"><i class="icofont icofont-diamond"></i></span>
    		</div>
    		<div class="row content service-grid-s1">
    			<!-- single serivce-->
          <?php 
            $our_service = null;
            $our_service = new WP_query(array(
              'post_type'       =>'our_services',
              'posts_per_page'  =>-1,
              'order' => 'ASC',
            ));
            if ($our_service->have_posts()) {
              while($our_service->have_posts()){
                $our_service->the_post();
                $service_icon = get_post_meta(get_the_ID(),'service_icon', true);
                ?>
    			<div class="col-md-4 col-sm-6">
    				<div class="grid">
    					<div class="icon">
                 <i class="fa fa-<?php echo $service_icon;?>"></i>
              </div>
              <div class="details">
                  <h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                  <p><?php echo wp_trim_words(get_the_content(),30, '.....');?></p>
              </div>
    				</div>
    			</div>
    			<?php } }
          else{
            echo "You have no post";
          }

          wp_reset_postdata();
          ?>
    		</div>
    	</div>
    </section>
    <!-- == Service Section End == -->