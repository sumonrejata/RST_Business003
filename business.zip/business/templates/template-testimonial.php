<section class="testimonial section-padding-top bg-silver">
	<div class="container">
		<div class="section-title">
			<h2>WHAT <span>CLIENT</span> SAY</h2>
			<span class="s-title-icon"><i class="icofont icofont-diamond"></i></span>
		</div>
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class=" testimonial-slide one-item">
					<div id="testimonial" class="swiper-wrapper owl-carousel">
						<?php  
						$testimonial = null;
						$testimonial = new WP_query(array(
							'post_type' 		=> 'testimonial',
							'post_per_page' 	=> -1, 
						));
						if ($testimonial->have_posts()) {
							while ($testimonial->have_posts()) {
								$testimonial->the_post(); ?>
								<div class="swiper-slide">
									<div class="testimonial-item style-4">
										<div class="testimonial-thumb">
											<!-- image -->
											<?php
											if ( has_post_thumbnail() ) :
												the_post_thumbnail('testimonial');
											endif;
											?>
										</div>
										<div class="review-txt">
											<span>“</span>
											<p><?php the_content();?></p>
											<span>”</span>
										</div>
										<div class="reviewer-details">
											<h3 class="reviewer-name"> - <?php the_title();?></h3>
											<h4 class="reviewer-deg">XYZ Inc.</h4>
										</div>
									</div>
								</div>
							<?php }
						}
						else{
							echo "you have no post";
						}
						wp_reset_postdata();
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>